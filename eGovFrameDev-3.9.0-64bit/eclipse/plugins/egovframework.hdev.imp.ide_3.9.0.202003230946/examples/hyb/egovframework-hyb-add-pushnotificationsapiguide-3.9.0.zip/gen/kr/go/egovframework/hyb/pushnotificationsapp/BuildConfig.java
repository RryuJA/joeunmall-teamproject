/** Automatically generated file. DO NOT MODIFY */
package kr.go.egovframework.hyb.pushnotificationsapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}