package com.joeunjsp.joeunmall.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

/** 
 * 
 * @author PJM
 *
 */


@Controller
@Slf4j

public class GetGraph_price_quantity_Controller {
	
	@GetMapping("/get Data")
	public void getData() {
		
	}
}
