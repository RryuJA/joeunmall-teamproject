package com.joeun.joeunmall;

import static org.junit.Assert.*;

import org.junit.Test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DemoTest {

	@Test
	public void test() {
		log.info("demotest");
	}

}
